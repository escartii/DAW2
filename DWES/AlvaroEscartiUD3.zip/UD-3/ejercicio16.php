<?php

/**
 * @Author: Álvaro Escartí
 */



$a = readline("introduce el valor de A: ");
$b = readline("introduce el valor de B: ");

$x = $b / $a;

echo "La solución de la ecuación es:  = $x";


?>