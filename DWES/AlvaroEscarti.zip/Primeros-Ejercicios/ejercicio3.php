<?php
/**
 * @Author: Álvaro Escartí
 */

$nombre = readline("Introduce tu nombre: ");
echo ("Hola " . $nombre . " Encantado de conocerte.\n¡Gracias por tu visita :D! \n");
?>