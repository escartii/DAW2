<?php

/**
 * @Author: Álvaro Escartí
 */


$pesetas = 1000;
$euros = $pesetas / 166.386;
echo "El resultado de convertir $pesetas pesetas a euros es: $euros\n";


?>
