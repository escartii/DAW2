<?php
/**
 * @Author: Álvaro Escartí
 */

$numero = readline("Introduce un número decimal: ");
// Función para redondear un número
$resultado = round($numero);
echo ("El resultado es: " . $resultado);
?>