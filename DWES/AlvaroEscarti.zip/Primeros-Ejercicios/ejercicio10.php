<?php

/**
 * @Author: Álvaro Escartí
 */


$minimo = 1;
$maximo = 5;

$saberNumero = rand($minimo,$maximo);

if ($saberNumero == 1) {
    echo $saberNumero . "=" . "uno\n";
}

if ($saberNumero == 2) {
    echo $saberNumero . "=" . "dos\n";
}

if ($saberNumero == 3) {
    echo $saberNumero . "=" . "tres\n";
}

if ($saberNumero == 4) {
    echo $saberNumero . "=" . "cuatro\n";
}

if ($saberNumero == 5) {
    echo $saberNumero . "=" . "cinco\n";
}



?>
