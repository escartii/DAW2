<?php
/**
 * @Author: Álvaro Escartí
 */

$numero1 = readline("Introduce el primer numero: ");
$numero2 = readline("Introduce el segundo numero: ");

echo ("La suma de: " . $numero1 . " + " . $numero2 . " es: " . ($numero1 + $numero2) . "\n");
echo ("La resta de: " . $numero1 . " - " . $numero2 . " es: " . ($numero1 - $numero2) . "\n");
echo ("La multiplicación de: " . $numero1 . " * " . $numero2 . " es: " . ($numero1 * $numero2) . "\n");
echo ("La división de: " . $numero1 . " / " . $numero2 . " es: " . ($numero1 / $numero2) . "\n");
?>


