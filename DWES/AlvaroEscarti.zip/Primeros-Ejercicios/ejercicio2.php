<?php
/**
 * @Author: Álvaro Escartí
 */
$nombre = readline("Dime tu nombre: ");
echo ("Hola " . $nombre . " Encantado de conocerte");
?>
