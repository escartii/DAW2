<?php

/**
 * @Author: Álvaro Escartí
 */


$euros = 10;
$pesetas = $euros * 166.386;
echo "$euros euros son $pesetas pesetas.\n";


?>