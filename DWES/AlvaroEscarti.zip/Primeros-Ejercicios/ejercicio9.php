<?php

/**
 * @Author: Álvaro Escartí
 */

$minimo = 10;
$maximo = 90;
$random = rand($minimo,$maximo);

echo "El dia obtenido es: " .$random . "\n";


?>